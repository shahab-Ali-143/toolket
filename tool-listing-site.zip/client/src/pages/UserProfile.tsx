import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Loader2, LogOut, Heart, Bookmark, Plus } from "lucide-react";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";
import { useState } from "react";

export default function UserProfile() {
  const { user, isAuthenticated, logout, loading } = useAuth();
  const [activeTab, setActiveTab] = useState<"bookmarks" | "submissions">("bookmarks");
  
  const { data: bookmarks, isLoading: bookmarksLoading } = trpc.bookmarks.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  
  const { data: submissions, isLoading: submissionsLoading } = trpc.submissions.listPending.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  // For regular users, we'll fetch their own submissions differently
  // For now, we'll show pending submissions only for admins
  const userSubmissions = user?.role === "admin" ? submissions : [];
  
  const logoutMutation = trpc.auth.logout.useMutation();

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen bg-background text-foreground py-12 px-4 flex items-center justify-center">
        <div className="cyber-card max-w-md text-center space-y-6">
          <h1 className="text-3xl font-black tracking-tighter">
            SIGN IN REQUIRED
          </h1>
          <p className="text-muted-foreground">
            Please sign in to view your profile and bookmarks.
          </p>
          <a href={getLoginUrl()}>
            <Button className="cyber-btn w-full">Sign In</Button>
          </a>
        </div>
      </div>
    );
  }

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      logout();
      toast.success("Logged out successfully");
    } catch (error) {
      toast.error("Failed to logout");
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-5xl font-black tracking-tighter mb-4">
            MY PROFILE
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-cyan-400 to-pink-300" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* User Info Card */}
          <div className="lg:col-span-1">
            <div className="cyber-card space-y-6 sticky top-4">
              <div>
                <h2 className="text-2xl font-bold text-primary mb-4">User Info</h2>
              </div>

              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Name</p>
                  <p className="text-lg font-bold text-foreground">{user.name || "N/A"}</p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Email</p>
                  <p className="text-lg font-bold text-foreground">{user.email || "N/A"}</p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Role</p>
                  <p className="text-lg font-bold text-foreground capitalize">
                    {user.role}
                  </p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Member Since</p>
                  <p className="text-lg font-bold text-foreground">
                    {new Date(user.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>

              <div className="border-t border-border pt-6 space-y-3">
                <Button
                  onClick={handleLogout}
                  className="w-full bg-destructive hover:bg-destructive/90 text-destructive-foreground font-bold"
                  disabled={logoutMutation.isPending}
                >
                  <LogOut className="mr-2 w-4 h-4" />
                  {logoutMutation.isPending ? "Logging out..." : "Logout"}
                </Button>

                {user.role === "admin" && (
                  <Link href="/admin">
                    <Button className="cyber-btn w-full">
                      Admin Panel
                    </Button>
                  </Link>
                )}

                <Link href="/submit">
                  <Button className="w-full border border-border" variant="outline">
                    <Plus className="mr-2 w-4 h-4" />
                    Submit Tool
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Tabs */}
            <div className="flex gap-4 border-b border-border mb-8">
              <button
                onClick={() => setActiveTab("bookmarks")}
                className={`px-4 py-3 font-bold border-b-2 transition-colors ${
                  activeTab === "bookmarks"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Bookmark className="inline mr-2 w-4 h-4" />
                Bookmarks ({bookmarks?.length || 0})
              </button>
              <button
                onClick={() => setActiveTab("submissions")}
                className={`px-4 py-3 font-bold border-b-2 transition-colors ${
                  activeTab === "submissions"
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Plus className="inline mr-2 w-4 h-4" />
                Submissions ({submissions?.length || 0})
              </button>
            </div>

            {/* Bookmarks Tab */}
            {activeTab === "bookmarks" && (
              <div className="cyber-card">
                {bookmarksLoading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                ) : bookmarks && bookmarks.length > 0 ? (
                  <div className="space-y-4">
                    {bookmarks.map((bookmark: any) => (
                      <Link key={bookmark.id} href={`/tools/${bookmark.toolId}`}>
                        <div className="cyber-card cursor-pointer group hover:border-primary/50 transition-colors">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors line-clamp-1">
                                {bookmark.tool?.name || `Tool #${bookmark.toolId}`}
                              </h3>
                              <p className="text-sm text-muted-foreground mt-1">
                                Bookmarked on {new Date(bookmark.createdAt).toLocaleDateString()}
                              </p>
                              {bookmark.tool?.description && (
                                <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                                  {bookmark.tool.description}
                                </p>
                              )}
                            </div>
                            <Bookmark className="w-5 h-5 fill-primary text-primary flex-shrink-0 ml-4" />
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <Bookmark className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p className="mb-4">No bookmarked tools yet</p>
                    <Link href="/tools">
                      <Button className="cyber-btn">
                        <Plus className="mr-2 w-4 h-4" />
                        Browse Tools
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            )}

            {/* Submissions Tab */}
            {activeTab === "submissions" && (
              <div className="cyber-card">
                {submissionsLoading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                ) : userSubmissions && userSubmissions.length > 0 ? (
                  <div className="space-y-4">
                    {userSubmissions.map((submission: any) => (
                      <div key={submission.id} className="cyber-card">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="text-lg font-bold text-foreground">
                                {submission.tool?.name || `Tool #${submission.toolId}`}
                              </h3>
                              <span
                                className={`text-xs font-mono px-2 py-1 rounded capitalize ${
                                  submission.status === "approved"
                                    ? "bg-green-500/20 text-green-600"
                                    : submission.status === "rejected"
                                      ? "bg-red-500/20 text-red-600"
                                      : "bg-yellow-500/20 text-yellow-600"
                                }`}
                              >
                                {submission.status}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              Submitted on {new Date(submission.createdAt).toLocaleDateString()}
                            </p>
                            {submission.rejectionReason && (
                              <p className="text-sm text-red-600 mt-2">
                                Reason: {submission.rejectionReason}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <Plus className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p className="mb-4">{user?.role === "admin" ? "No pending submissions" : "Feature coming soon"}</p>
                    <Link href="/submit">
                      <Button className="cyber-btn">
                        <Plus className="mr-2 w-4 h-4" />
                        Submit a Tool
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
