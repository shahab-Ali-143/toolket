import { useState, useMemo } from "react";
import { Link, useSearch } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Search, Heart, Bookmark, BookmarkCheck, ChevronLeft, ChevronRight } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

const ITEMS_PER_PAGE = 12;

export default function ToolsDirectory() {
  const { user, isAuthenticated } = useAuth();
  const search = useSearch();
  const params = new URLSearchParams(search);

  const [query, setQuery] = useState(params.get("q") || "");
  const [selectedCategory, setSelectedCategory] = useState<number | undefined>(
    params.get("category") ? parseInt(params.get("category")!) : undefined
  );
  const [selectedPricing, setSelectedPricing] = useState<string | undefined>(
    params.get("pricing") || undefined
  );
  const [currentPage, setCurrentPage] = useState(0);

  const { data: tools, isLoading: toolsLoading } = trpc.tools.search.useQuery({
    query: query || undefined,
    categoryId: selectedCategory,
    pricingType: selectedPricing as any,
  });

  const { data: categories } = trpc.categories.list.useQuery();
  const { data: bookmarks } = trpc.bookmarks.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const bookmarkMutation = trpc.bookmarks.add.useMutation();
  const removeBookmarkMutation = trpc.bookmarks.remove.useMutation();

  const bookmarkedToolIds = useMemo(
    () => new Set(bookmarks?.map((b) => b.toolId) || []),
    [bookmarks]
  );

  const handleBookmark = (toolId: number, isBookmarked: boolean) => {
    if (!isAuthenticated) {
      toast.error("Please sign in to bookmark tools");
      return;
    }

    if (isBookmarked) {
      removeBookmarkMutation.mutate(
        { toolId },
        {
          onSuccess: () => toast.success("Bookmark removed"),
          onError: () => toast.error("Failed to remove bookmark"),
        }
      );
    } else {
      bookmarkMutation.mutate(
        { toolId },
        {
          onSuccess: () => toast.success("Tool bookmarked!"),
          onError: () => toast.error("Failed to bookmark tool"),
        }
      );
    }
  };

  const pricingOptions = ["free", "freemium", "paid", "open-source"];

  // Pagination
  const totalPages = Math.ceil((tools?.length || 0) / ITEMS_PER_PAGE);
  const paginatedTools = useMemo(() => {
    const start = currentPage * ITEMS_PER_PAGE;
    return (tools || []).slice(start, start + ITEMS_PER_PAGE);
  }, [tools, currentPage]);

  return (
    <div className="min-h-screen bg-background text-foreground py-12 px-4">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-5xl font-black tracking-tighter mb-4 neon-text">
            TOOL DIRECTORY
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-primary to-secondary" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Filters */}
          <div className="lg:col-span-1">
            <div className="space-y-6 sticky top-20">
              {/* Search */}
              <div className="cyber-card">
                <h3 className="font-bold text-primary mb-4 uppercase tracking-wider">
                  Search
                </h3>
                <div className="relative">
                  <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search tools..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    className="cyber-input pl-10"
                  />
                </div>
              </div>

              {/* Categories Filter */}
              {categories && categories.length > 0 && (
                <div className="cyber-card">
                  <h3 className="font-bold text-secondary mb-4 uppercase tracking-wider">
                    Categories
                  </h3>
                  <div className="space-y-2">
                    <button
                      onClick={() => setSelectedCategory(undefined)}
                      className={`block w-full text-left px-3 py-2 rounded text-sm transition-colors ${
                        !selectedCategory
                          ? "bg-primary/20 text-primary"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      All Categories
                    </button>
                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedCategory(cat.id)}
                        className={`block w-full text-left px-3 py-2 rounded text-sm transition-colors ${
                          selectedCategory === cat.id
                            ? "bg-primary/20 text-primary"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {cat.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Pricing Filter */}
              <div className="cyber-card">
                <h3 className="font-bold text-secondary mb-4 uppercase tracking-wider">
                  Pricing
                </h3>
                <div className="space-y-2">
                  <button
                    onClick={() => setSelectedPricing(undefined)}
                    className={`block w-full text-left px-3 py-2 rounded text-sm transition-colors ${
                      !selectedPricing
                        ? "bg-primary/20 text-primary"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    All Pricing
                  </button>
                  {pricingOptions.map((pricing) => (
                    <button
                      key={pricing}
                      onClick={() => setSelectedPricing(pricing)}
                      className={`block w-full text-left px-3 py-2 rounded text-sm transition-colors capitalize ${
                        selectedPricing === pricing
                          ? "bg-primary/20 text-primary"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {pricing}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Tools Grid */}
          <div className="lg:col-span-3">
            {toolsLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : tools && tools.length > 0 ? (
              <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {paginatedTools.map((tool) => {
                  const isBookmarked = bookmarkedToolIds.has(tool.id);
                  return (
                    <div key={tool.id} className="cyber-card group relative">
                      <Link href={`/tools/${tool.id}`}>
                        <div className="cursor-pointer">
                          <div className="flex items-start justify-between mb-4">
                            <h3 className="text-xl font-bold text-primary group-hover:text-secondary transition-colors flex-1">
                              {tool.name}
                            </h3>
                            <button
                              onClick={(e) => {
                                e.preventDefault();
                                handleBookmark(tool.id, isBookmarked);
                              }}
                              className="ml-2 p-2 hover:bg-primary/20 rounded transition-colors"
                            >
                              {isBookmarked ? (
                                <BookmarkCheck className="w-5 h-5 text-primary" />
                              ) : (
                                <Bookmark className="w-5 h-5 text-muted-foreground hover:text-primary" />
                              )}
                            </button>
                          </div>

                          <p className="text-sm text-muted-foreground mb-4 line-clamp-3">
                            {tool.aiSummary || tool.description}
                          </p>

                          <div className="flex items-center justify-between pt-4 border-t border-primary/30">
                            <div className="flex gap-2 flex-wrap">
                              <span className="cyber-badge text-xs">
                                {tool.pricingType.toUpperCase()}
                              </span>
                            </div>
                            <div className="text-sm font-bold text-secondary">
                              ★ {parseFloat(tool.rating || "0").toFixed(1)}
                            </div>
                          </div>
                        </div>
                      </Link>
                    </div>
                  );
                })}
              </div>

              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 mt-8">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
                    disabled={currentPage === 0}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>

                  <div className="flex items-center gap-1">
                    {Array.from({ length: totalPages }).map((_, i) => (
                      <Button
                        key={i}
                        variant={currentPage === i ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCurrentPage(i)}
                        className="w-10 h-10 p-0"
                      >
                        {i + 1}
                      </Button>
                    ))}
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage(Math.min(totalPages - 1, currentPage + 1))}
                    disabled={currentPage === totalPages - 1}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              )}
              </>
            ) : (
              <div className="cyber-card text-center py-12">
                <p className="text-muted-foreground text-lg">
                  No tools found matching your criteria.
                </p>
                <Button
                  onClick={() => {
                    setQuery("");
                    setSelectedCategory(undefined);
                    setSelectedPricing(undefined);
                  }}
                  className="cyber-btn mt-6"
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
