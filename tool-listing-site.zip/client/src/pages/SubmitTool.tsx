import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Zap } from "lucide-react";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";

export default function SubmitTool() {
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    websiteUrl: "",
    documentationUrl: "",
    categoryId: "",
    pricingType: "free" as const,
  });
  const [suggestedTags, setSuggestedTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");

  const { data: categories } = trpc.categories.list.useQuery();
  const submitMutation = trpc.submissions.create.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background text-foreground py-12 px-4 flex items-center justify-center">
        <div className="cyber-card max-w-md text-center space-y-6">
          <h1 className="text-3xl font-black tracking-tighter neon-text">
            SIGN IN REQUIRED
          </h1>
          <p className="text-muted-foreground">
            You need to be signed in to submit a tool to the directory.
          </p>
          <a href={getLoginUrl()}>
            <Button className="cyber-btn w-full">Sign In</Button>
          </a>
        </div>
      </div>
    );
  }

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !suggestedTags.includes(tagInput.trim())) {
      setSuggestedTags((prev) => [...prev, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (tag: string) => {
    setSuggestedTags((prev) => prev.filter((t) => t !== tag));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim()) {
      toast.error("Tool name is required");
      return;
    }

    if (!formData.description.trim()) {
      toast.error("Tool description is required");
      return;
    }

    if (!formData.categoryId) {
      toast.error("Please select a category");
      return;
    }

    submitMutation.mutate(
      {
        name: formData.name,
        description: formData.description,
        websiteUrl: formData.websiteUrl || undefined,
        documentationUrl: formData.documentationUrl || undefined,
        categoryId: parseInt(formData.categoryId),
        pricingType: formData.pricingType,
        suggestedTags,
      },
      {
        onSuccess: () => {
          toast.success("Tool submitted! It will be reviewed by our team.");
          navigate("/tools", { replace: true });
        },
        onError: (error) => {
          toast.error("Failed to submit tool");
          console.error(error);
        },
      }
    );
  };

  return (
    <div className="min-h-screen bg-background text-foreground py-12 px-4">
      <div className="container mx-auto max-w-2xl">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-5xl font-black tracking-tighter mb-4 neon-text">
            SUBMIT TOOL
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-primary to-secondary" />
          <p className="text-muted-foreground mt-4">
            Share an amazing AI tool with our community. Our team will review and publish it.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Tool Name */}
          <div className="cyber-card">
            <label className="block text-sm font-bold text-primary mb-2">
              Tool Name *
            </label>
            <Input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              placeholder="e.g., ChatGPT, Midjourney, etc."
              className="cyber-input w-full"
              required
            />
          </div>

          {/* Description */}
          <div className="cyber-card">
            <label className="block text-sm font-bold text-primary mb-2">
              Description *
            </label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleInputChange}
              placeholder="Describe what this tool does and why it's useful..."
              className="cyber-input w-full h-32 resize-none"
              required
            />
            <p className="text-xs text-muted-foreground mt-2">
              Our AI will automatically generate a summary from this description.
            </p>
          </div>

          {/* Category */}
          <div className="cyber-card">
            <label className="block text-sm font-bold text-primary mb-2">
              Category *
            </label>
            <select
              name="categoryId"
              value={formData.categoryId}
              onChange={handleInputChange}
              className="cyber-input w-full"
              required
            >
              <option value="">Select a category</option>
              {categories?.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
          </div>

          {/* Pricing Type */}
          <div className="cyber-card">
            <label className="block text-sm font-bold text-primary mb-2">
              Pricing Type *
            </label>
            <select
              name="pricingType"
              value={formData.pricingType}
              onChange={handleInputChange}
              className="cyber-input w-full"
              required
            >
              <option value="free">Free</option>
              <option value="freemium">Freemium</option>
              <option value="paid">Paid</option>
              <option value="open-source">Open Source</option>
            </select>
          </div>

          {/* Website URL */}
          <div className="cyber-card">
            <label className="block text-sm font-bold text-primary mb-2">
              Website URL
            </label>
            <Input
              type="url"
              name="websiteUrl"
              value={formData.websiteUrl}
              onChange={handleInputChange}
              placeholder="https://example.com"
              className="cyber-input w-full"
            />
          </div>

          {/* Documentation URL */}
          <div className="cyber-card">
            <label className="block text-sm font-bold text-primary mb-2">
              Documentation URL
            </label>
            <Input
              type="url"
              name="documentationUrl"
              value={formData.documentationUrl}
              onChange={handleInputChange}
              placeholder="https://docs.example.com"
              className="cyber-input w-full"
            />
          </div>

          {/* Tags */}
          <div className="cyber-card">
            <label className="block text-sm font-bold text-primary mb-2">
              Tags
            </label>
            <p className="text-xs text-muted-foreground mb-3">
              Add tags to help categorize this tool (e.g., AI, ML, NLP, etc.)
            </p>
            <div className="flex gap-2 mb-4">
              <Input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
                placeholder="Type a tag and press Enter"
                className="cyber-input flex-1"
              />
              <Button
                type="button"
                onClick={handleAddTag}
                className="cyber-btn"
              >
                Add
              </Button>
            </div>
            {suggestedTags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {suggestedTags.map((tag) => (
                  <div
                    key={tag}
                    className="cyber-badge flex items-center gap-2"
                  >
                    {tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="ml-1 hover:text-destructive"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Submit Button */}
          <div className="flex gap-4">
            <Button
              type="submit"
              className="cyber-btn flex-1 py-6 text-lg"
              disabled={submitMutation.isPending}
            >
              {submitMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Zap className="mr-2 w-5 h-5" />
                  Submit Tool
                </>
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate("/tools")}
              className="px-8 py-6 border-2 border-secondary text-secondary hover:bg-secondary/10"
            >
              Cancel
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
