import { useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Loader2, Heart, ExternalLink, BookOpen, Star, Bookmark, BookmarkCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function ToolDetail() {
  const { id } = useParams<{ id: string }>();
  const toolId = parseInt(id || "0");
  const { user, isAuthenticated } = useAuth();
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");

  const { data: tool, isLoading } = trpc.tools.getById.useQuery({ id: toolId });
  const { data: isBookmarked } = trpc.bookmarks.isBookmarked.useQuery(
    { toolId },
    { enabled: isAuthenticated }
  );

  const bookmarkMutation = trpc.bookmarks.add.useMutation();
  const removeBookmarkMutation = trpc.bookmarks.remove.useMutation();
  const reviewMutation = trpc.reviews.create.useMutation();

  const handleBookmark = () => {
    if (!isAuthenticated) return;

    if (isBookmarked) {
      removeBookmarkMutation.mutate({ toolId });
    } else {
      bookmarkMutation.mutate({ toolId });
    }
  };

  const handleSubmitReview = () => {
    if (!isAuthenticated) {
      toast.error("Please sign in to leave a review");
      return;
    }

    if (rating === 0) {
      toast.error("Please select a rating");
      return;
    }

    reviewMutation.mutate(
      { toolId, rating, comment },
      {
        onSuccess: () => {
          setRating(0);
          setComment("");
          toast.success("Review submitted!");
        },
        onError: () => {
          toast.error("Failed to submit review");
        },
      }
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!tool) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-primary mb-4">Tool Not Found</h1>
          <p className="text-muted-foreground">The tool you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground py-12 px-4">
      <div className="container mx-auto max-w-4xl">
        {/* Header */}
        <div className="cyber-card mb-8">
          <div className="flex items-start justify-between mb-6">
            <div className="flex-1">
              <h1 className="text-5xl font-black tracking-tighter mb-2 neon-text">
                {tool.name}
              </h1>
              <div className="flex items-center gap-4 mt-4">
                <div className="flex gap-2">
                  <span className="cyber-badge">{tool.pricingType.toUpperCase()}</span>
                  {tool.featured && <span className="cyber-badge-cyan">FEATURED</span>}
                </div>
                <div className="flex items-center gap-1">
                  <Star className="w-5 h-5 fill-secondary text-secondary" />
                  <span className="text-lg font-bold text-secondary">
                    {parseFloat(tool.rating || "0").toFixed(1)}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    ({tool.reviewCount} reviews)
                  </span>
                </div>
              </div>
            </div>
            {isAuthenticated && (
              <button
                onClick={handleBookmark}
                className="p-3 hover:bg-primary/20 rounded transition-colors"
              >
                <Heart
                  className={`w-6 h-6 ${
                    isBookmarked ? "fill-primary text-primary" : "text-muted-foreground"
                  }`}
                />
              </button>
            )}
          </div>

          <p className="text-lg text-muted-foreground mb-6">{tool.description}</p>

          {tool.aiSummary && (
            <div className="bg-primary/10 border border-primary/30 p-4 rounded mb-6">
              <p className="text-sm text-primary font-bold mb-2">AI SUMMARY</p>
              <p className="text-foreground">{tool.aiSummary}</p>
            </div>
          )}

          <div className="flex gap-4">
            {tool.websiteUrl && (
              <a href={tool.websiteUrl} target="_blank" rel="noopener noreferrer">
                <Button className="cyber-btn">
                  <ExternalLink className="mr-2 w-4 h-4" />
                  Visit Website
                </Button>
              </a>
            )}
            {tool.documentationUrl && (
              <a href={tool.documentationUrl} target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="border-2 border-secondary text-secondary">
                  <BookOpen className="mr-2 w-4 h-4" />
                  Documentation
                </Button>
              </a>
            )}
          </div>
        </div>

        {/* Tags */}
        {tool.tags && tool.tags.length > 0 && (
          <div className="cyber-card mb-8">
            <h2 className="text-2xl font-bold text-secondary mb-4 uppercase tracking-wider">
              Tags
            </h2>
            <div className="flex flex-wrap gap-2">
              {tool.tags.map((tag) => (
                <span key={tag.id} className="cyber-badge-cyan">
                  {tag.name}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Reviews Section */}
        <div className="cyber-card mb-8">
          <h2 className="text-2xl font-bold text-primary mb-6 uppercase tracking-wider">
            Reviews
          </h2>

          {isAuthenticated && (
            <div className="mb-8 pb-8 border-b border-primary/30">
              <h3 className="font-bold text-secondary mb-4">Leave a Review</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-primary mb-2">Rating</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((r) => (
                      <button
                        key={r}
                        onClick={() => setRating(r)}
                        className={`p-2 rounded transition-colors ${
                          rating >= r
                            ? "bg-secondary/20 text-secondary"
                            : "bg-primary/10 text-muted-foreground"
                        }`}
                      >
                        <Star className="w-6 h-6 fill-current" />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-primary mb-2">Comment</label>
                  <textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Share your thoughts about this tool..."
                    className="cyber-input w-full h-24 resize-none"
                  />
                </div>
                <Button
                  onClick={handleSubmitReview}
                  className="cyber-btn"
                  disabled={reviewMutation.isPending}
                >
                  {reviewMutation.isPending ? "Submitting..." : "Submit Review"}
                </Button>
              </div>
            </div>
          )}

          {tool.reviews && tool.reviews.length > 0 ? (
            <div className="space-y-4">
              {tool.reviews.map((review) => (
                <div key={review.id} className="bg-primary/5 p-4 rounded border border-primary/20">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < review.rating
                              ? "fill-secondary text-secondary"
                              : "text-muted-foreground"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {new Date(review.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  {review.comment && (
                    <p className="text-sm text-foreground">{review.comment}</p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">No reviews yet. Be the first!</p>
          )}
        </div>
      </div>
    </div>
  );
}
