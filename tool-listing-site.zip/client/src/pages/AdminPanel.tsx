import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";

export default function AdminPanel() {
  const { user } = useAuth();
  const [rejectionReason, setRejectionReason] = useState<{ [key: number]: string }>({});

  const { data: submissions, isLoading, refetch } = trpc.submissions.listPending.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const approveMutation = trpc.submissions.approve.useMutation();
  const rejectMutation = trpc.submissions.reject.useMutation();

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="cyber-card text-center max-w-md">
          <h1 className="text-2xl font-bold text-primary mb-4">ACCESS DENIED</h1>
          <p className="text-muted-foreground">
            You don't have permission to access the admin panel.
          </p>
        </div>
      </div>
    );
  }

  const handleApprove = (submissionId: number) => {
    approveMutation.mutate(
      { submissionId },
      {
        onSuccess: () => {
          toast.success("Tool approved!");
          refetch();
        },
        onError: () => {
          toast.error("Failed to approve tool");
        },
      }
    );
  };

  const handleReject = (submissionId: number) => {
    const reason = rejectionReason[submissionId] || "";
    if (!reason.trim()) {
      toast.error("Please provide a rejection reason");
      return;
    }

    rejectMutation.mutate(
      { submissionId, reason },
      {
        onSuccess: () => {
          toast.success("Tool rejected");
          setRejectionReason((prev) => {
            const newReasons = { ...prev };
            delete newReasons[submissionId];
            return newReasons;
          });
          refetch();
        },
        onError: () => {
          toast.error("Failed to reject tool");
        },
      }
    );
  };

  return (
    <div className="min-h-screen bg-background text-foreground py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-5xl font-black tracking-tighter mb-4 neon-text">
            ADMIN PANEL
          </h1>
          <div className="w-32 h-1 bg-gradient-to-r from-primary to-secondary" />
          <p className="text-muted-foreground mt-4">
            Review and moderate tool submissions
          </p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : submissions && submissions.length > 0 ? (
          <div className="space-y-6">
            {submissions.map((submission: any) => (
              <div key={submission.id} className="cyber-card">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-2xl font-bold text-primary mb-2">
                      {submission.toolId}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Submitted by: User #{submission.submittedBy}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(submission.createdAt).toLocaleString()}
                    </p>
                  </div>

                  <div className="bg-primary/10 p-4 rounded border border-primary/30">
                    <p className="text-foreground">
                      Tool ID: {submission.toolId}
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-bold text-secondary mb-2">
                        Rejection Reason (if rejecting)
                      </label>
                      <textarea
                        value={rejectionReason[submission.id] || ""}
                        onChange={(e) =>
                          setRejectionReason((prev) => ({
                            ...prev,
                            [submission.id]: e.target.value,
                          }))
                        }
                        placeholder="Explain why this tool is being rejected..."
                        className="cyber-input w-full h-20 resize-none"
                      />
                    </div>

                    <div className="flex gap-4">
                      <Button
                        onClick={() => handleApprove(submission.id)}
                        className="cyber-btn flex-1 flex items-center justify-center"
                        disabled={approveMutation.isPending}
                      >
                        <CheckCircle className="mr-2 w-5 h-5" />
                        Approve
                      </Button>
                      <Button
                        onClick={() => handleReject(submission.id)}
                        className="flex-1 bg-destructive hover:bg-destructive/90 text-destructive-foreground font-bold px-6 py-3 flex items-center justify-center"
                        disabled={rejectMutation.isPending}
                      >
                        <XCircle className="mr-2 w-5 h-5" />
                        Reject
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="cyber-card text-center py-12">
            <p className="text-muted-foreground text-lg">
              No pending submissions to review.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
