import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Loader2, Zap, Grid3x3, TrendingUp, Plus } from "lucide-react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading: authLoading } = useAuth();
  const { data: featuredTools, isLoading: featuredLoading } = trpc.tools.featured.useQuery({ limit: 6 });
  const { data: categories, isLoading: categoriesLoading } = trpc.categories.list.useQuery();
  const { data: recentTools, isLoading: recentLoading } = trpc.tools.list.useQuery({ limit: 8, offset: 0 });

  const isLoading = featuredLoading || categoriesLoading || recentLoading;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Blueprint Background */}
      <div className="fixed inset-0 opacity-5 pointer-events-none">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Hero Section */}
      <section className="relative py-24 px-4 sm:py-32 overflow-hidden">
        <div className="absolute inset-0 opacity-10 pointer-events-none">
          <div className="absolute top-10 right-20 w-72 h-72 bg-cyan-400 rounded-full mix-blend-multiply filter blur-3xl" />
          <div className="absolute bottom-10 left-20 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl" />
        </div>

        <div className="container mx-auto max-w-4xl relative z-10">
          <div className="text-center space-y-8">
            <div className="inline-flex items-center justify-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/5">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-mono text-primary">Discover AI Tools</span>
            </div>

            <h1 className="text-5xl sm:text-7xl font-black tracking-tighter text-foreground leading-tight">
              The Ultimate
              <br />
              <span className="bg-gradient-to-r from-cyan-400 to-pink-300 bg-clip-text text-transparent">
                Tool Directory
              </span>
            </h1>

            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Discover the most powerful AI tools and services. Curated, reviewed, and ranked by the community. Find exactly what you need to accelerate your workflow.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Link href="/tools">
                <Button size="lg" className="cyber-btn w-full sm:w-auto">
                  <Grid3x3 className="mr-2 w-5 h-5" />
                  Browse Tools
                </Button>
              </Link>
              {user ? (
                <Link href="/submit">
                  <Button size="lg" variant="outline" className="w-full sm:w-auto">
                    <Plus className="mr-2 w-5 h-5" />
                    Submit Tool
                  </Button>
                </Link>
              ) : (
                <a href={getLoginUrl()}>
                  <Button size="lg" variant="outline" className="w-full sm:w-auto">
                    <Plus className="mr-2 w-5 h-5" />
                    Sign In to Submit
                  </Button>
                </a>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Tools Section */}
      {featuredTools && featuredTools.length > 0 && (
        <section className="py-20 px-4 border-t border-border">
          <div className="container mx-auto max-w-6xl">
            <div className="mb-12">
              <div className="flex items-center gap-3 mb-4">
                <Zap className="w-6 h-6 text-primary" />
                <h2 className="text-4xl font-black tracking-tighter">Featured Tools</h2>
              </div>
              <p className="text-muted-foreground">Top-rated tools handpicked for excellence</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredTools.map((tool) => (
                <Link key={tool.id} href={`/tools/${tool.id}`}>
                  <div className="cyber-card group cursor-pointer h-full hover:border-primary/50 transition-colors">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <h3 className="font-bold text-lg text-foreground group-hover:text-primary transition-colors line-clamp-2">
                          {tool.name}
                        </h3>
                        <span className="text-xs font-mono px-2 py-1 rounded bg-primary/10 text-primary whitespace-nowrap ml-2">
                          {tool.pricingType}
                        </span>
                      </div>

                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {tool.aiSummary || tool.description}
                      </p>

                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-1">
                          <span className="text-yellow-400">★</span>
                          <span className="text-sm font-semibold">{tool.rating || "0"}</span>
                          <span className="text-xs text-muted-foreground">({tool.reviewCount || 0})</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Categories Section */}
      {categories && categories.length > 0 && (
        <section className="py-20 px-4 bg-primary/5 border-t border-border">
          <div className="container mx-auto max-w-6xl">
            <div className="mb-12">
              <div className="flex items-center gap-3 mb-4">
                <Grid3x3 className="w-6 h-6 text-primary" />
                <h2 className="text-4xl font-black tracking-tighter">Popular Categories</h2>
              </div>
              <p className="text-muted-foreground">Explore tools by category</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {categories.slice(0, 8).map((category) => (
                <Link key={category.id} href={`/tools?category=${category.id}`}>
                  <div className="cyber-card group cursor-pointer text-center py-6 hover:border-primary/50 transition-colors">
                    <h3 className="font-bold text-foreground group-hover:text-primary transition-colors">
                      {category.name}
                    </h3>
                    {category.description && (
                      <p className="text-xs text-muted-foreground mt-2 line-clamp-1">
                        {category.description}
                      </p>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Recent Additions Section */}
      {recentTools && recentTools.length > 0 && (
        <section className="py-20 px-4 border-t border-border">
          <div className="container mx-auto max-w-6xl">
            <div className="mb-12">
              <div className="flex items-center gap-3 mb-4">
                <TrendingUp className="w-6 h-6 text-primary" />
                <h2 className="text-4xl font-black tracking-tighter">Recently Added</h2>
              </div>
              <p className="text-muted-foreground">Latest tools added to the directory</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {recentTools.map((tool) => (
                <Link key={tool.id} href={`/tools/${tool.id}`}>
                  <div className="cyber-card group cursor-pointer h-full hover:border-primary/50 transition-colors">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <h3 className="font-bold text-foreground group-hover:text-primary transition-colors line-clamp-2">
                          {tool.name}
                        </h3>
                      </div>

                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {tool.aiSummary || tool.description}
                      </p>

                      <div className="flex items-center justify-between pt-2">
                        <span className="text-xs font-mono px-2 py-1 rounded bg-primary/10 text-primary">
                          {tool.pricingType}
                        </span>
                        <div className="flex items-center gap-1">
                          <span className="text-yellow-400">★</span>
                          <span className="text-xs font-semibold">{tool.rating || "0"}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            <div className="text-center mt-12">
              <Link href="/tools">
                <Button size="lg" variant="outline">
                  View All Tools
                </Button>
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-cyan-400/10 to-pink-300/10 border-t border-border">
        <div className="container mx-auto max-w-2xl text-center space-y-6">
          <h2 className="text-4xl font-black tracking-tighter">
            Have a tool to share?
          </h2>
          <p className="text-lg text-muted-foreground">
            Help the community discover amazing tools. Submit yours today.
          </p>
          {user ? (
            <Link href="/submit">
              <Button size="lg" className="cyber-btn">
                <Plus className="mr-2 w-5 h-5" />
                Submit Your Tool
              </Button>
            </Link>
          ) : (
            <a href={getLoginUrl()}>
              <Button size="lg" className="cyber-btn">
                <Plus className="mr-2 w-5 h-5" />
                Sign In & Submit
              </Button>
            </a>
          )}
        </div>
      </section>
    </div>
  );
}
