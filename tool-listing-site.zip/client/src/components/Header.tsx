import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/contexts/ThemeContext";
import { Link } from "wouter";
import { Menu, X, Moon, Sun, LogOut, User, Settings } from "lucide-react";
import { useState } from "react";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Header() {
  const { user, loading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const logoutMutation = trpc.auth.logout.useMutation();

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        toast.success("Logged out successfully");
        window.location.href = "/";
      },
      onError: () => {
        toast.error("Failed to logout");
      },
    });
  };

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto max-w-7xl px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer">
            <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 to-pink-300 rounded flex items-center justify-center">
              <span className="text-xs font-black text-white">T</span>
            </div>
            <span className="font-black text-lg tracking-tighter hidden sm:inline">NEXUS</span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <Link href="/tools">
            <span className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
              Browse
            </span>
          </Link>
          {user && (
            <Link href="/submit">
              <span className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                Submit
              </span>
            </Link>
          )}
          {user?.role === "admin" && (
            <Link href="/admin">
              <span className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                Admin
              </span>
            </Link>
          )}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 hover:bg-primary/10 rounded transition-colors"
            aria-label="Toggle theme"
          >
            {theme === "dark" ? (
              <Sun className="w-5 h-5 text-muted-foreground" />
            ) : (
              <Moon className="w-5 h-5 text-muted-foreground" />
            )}
          </button>

          {/* Auth Actions */}
          {loading ? (
            <div className="w-8 h-8 bg-primary/20 rounded animate-pulse" />
          ) : user ? (
            <div className="flex items-center gap-2">
              <Link href="/profile">
                <Button size="sm" variant="outline">
                  <User className="w-4 h-4 mr-2" />
                  Profile
                </Button>
              </Link>
              <Button
                size="sm"
                variant="outline"
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          ) : (
            <a href={getLoginUrl()}>
              <Button size="sm" className="cyber-btn">
                Sign In
              </Button>
            </a>
          )}

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 hover:bg-primary/10 rounded transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-background">
          <nav className="container mx-auto max-w-7xl px-4 py-4 space-y-3">
            <Link href="/tools">
              <div
                className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                Browse Tools
              </div>
            </Link>
            {user && (
              <>
                <Link href="/submit">
                  <div
                    className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer py-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Submit Tool
                  </div>
                </Link>
                <Link href="/profile">
                  <div
                    className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer py-2"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    My Profile
                  </div>
                </Link>
              </>
            )}
            {user?.role === "admin" && (
              <Link href="/admin">
                <div
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer py-2"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Admin Panel
                </div>
              </Link>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
