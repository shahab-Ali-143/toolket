import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('DATABASE_URL environment variable is not set');
  process.exit(1);
}

async function seedDatabase() {
  let connection;
  try {
    // Parse DATABASE_URL
    const url = new URL(DATABASE_URL);
    const config = {
      host: url.hostname,
      user: url.username,
      password: url.password,
      database: url.pathname.slice(1),
      port: url.port || 3306,
    };

    connection = await mysql.createConnection(config);
    console.log('Connected to database');

    // Insert categories
    const categories = [
      { name: 'Writing & Content', slug: 'writing-content', description: 'AI tools for writing, editing, and content creation' },
      { name: 'Image Generation', slug: 'image-generation', description: 'AI image generators and visual design tools' },
      { name: 'Code & Development', slug: 'code-development', description: 'AI coding assistants and development tools' },
      { name: 'Business & Productivity', slug: 'business-productivity', description: 'Tools for business automation and productivity' },
      { name: 'Video & Audio', slug: 'video-audio', description: 'AI video and audio processing tools' },
      { name: 'Research & Analysis', slug: 'research-analysis', description: 'Data analysis and research tools' },
    ];

    for (const cat of categories) {
      await connection.execute(
        'INSERT IGNORE INTO categories (name, slug, description) VALUES (?, ?, ?)',
        [cat.name, cat.slug, cat.description]
      );
    }
    console.log('✓ Categories seeded');

    // Insert tags
    const tags = [
      { name: 'AI', slug: 'ai' },
      { name: 'Machine Learning', slug: 'machine-learning' },
      { name: 'NLP', slug: 'nlp' },
      { name: 'Computer Vision', slug: 'computer-vision' },
      { name: 'Automation', slug: 'automation' },
      { name: 'Productivity', slug: 'productivity' },
      { name: 'Design', slug: 'design' },
      { name: 'Development', slug: 'development' },
      { name: 'Analytics', slug: 'analytics' },
      { name: 'Enterprise', slug: 'enterprise' },
    ];

    for (const tag of tags) {
      await connection.execute(
        'INSERT IGNORE INTO tags (name, slug) VALUES (?, ?)',
        [tag.name, tag.slug]
      );
    }
    console.log('✓ Tags seeded');

    // Insert sample tools
    const tools = [
      {
        name: 'ChatGPT',
        slug: 'chatgpt',
        description: 'Advanced AI chatbot powered by GPT-4. Capable of understanding context, generating creative content, answering questions, and assisting with various tasks.',
        aiSummary: 'Advanced AI chatbot for conversations, content creation, and problem-solving.',
        websiteUrl: 'https://chat.openai.com',
        documentationUrl: 'https://platform.openai.com/docs',
        categoryId: 1,
        pricingType: 'freemium',
        rating: '4.8',
        reviewCount: 2543,
        submittedBy: 1,
        status: 'approved',
        featured: true,
      },
      {
        name: 'Midjourney',
        slug: 'midjourney',
        description: 'AI image generation tool that creates stunning visuals from text descriptions. Perfect for designers, artists, and creative professionals.',
        aiSummary: 'AI image generator creating high-quality visuals from text prompts.',
        websiteUrl: 'https://www.midjourney.com',
        documentationUrl: 'https://docs.midjourney.com',
        categoryId: 2,
        pricingType: 'paid',
        rating: '4.7',
        reviewCount: 1892,
        submittedBy: 1,
        status: 'approved',
        featured: true,
      },
      {
        name: 'GitHub Copilot',
        slug: 'github-copilot',
        description: 'AI-powered code completion and generation tool. Helps developers write code faster with intelligent suggestions and autocomplete.',
        aiSummary: 'AI coding assistant that generates code suggestions and completions.',
        websiteUrl: 'https://github.com/features/copilot',
        documentationUrl: 'https://docs.github.com/en/copilot',
        categoryId: 3,
        pricingType: 'paid',
        rating: '4.6',
        reviewCount: 1456,
        submittedBy: 1,
        status: 'approved',
        featured: true,
      },
      {
        name: 'Jasper',
        slug: 'jasper',
        description: 'AI writing assistant for marketing copy, blog posts, and content creation. Uses advanced language models to generate high-quality content.',
        aiSummary: 'AI writing assistant for creating marketing and content copy.',
        websiteUrl: 'https://www.jasper.ai',
        documentationUrl: 'https://www.jasper.ai/help',
        categoryId: 1,
        pricingType: 'paid',
        rating: '4.5',
        reviewCount: 987,
        submittedBy: 1,
        status: 'approved',
        featured: false,
      },
      {
        name: 'Synthesia',
        slug: 'synthesia',
        description: 'AI video generation platform. Create professional videos with AI avatars and voiceovers without expensive production equipment.',
        aiSummary: 'AI video generation tool with virtual avatars and voiceovers.',
        websiteUrl: 'https://www.synthesia.io',
        documentationUrl: 'https://www.synthesia.io/help',
        categoryId: 5,
        pricingType: 'paid',
        rating: '4.4',
        reviewCount: 654,
        submittedBy: 1,
        status: 'approved',
        featured: false,
      },
    ];

    for (const tool of tools) {
      const [result] = await connection.execute(
        'INSERT IGNORE INTO tools (name, slug, description, aiSummary, websiteUrl, documentationUrl, categoryId, pricingType, rating, reviewCount, submittedBy, status, featured, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())',
        [
          tool.name,
          tool.slug,
          tool.description,
          tool.aiSummary,
          tool.websiteUrl,
          tool.documentationUrl,
          tool.categoryId,
          tool.pricingType,
          tool.rating,
          tool.reviewCount,
          tool.submittedBy,
          tool.status,
          tool.featured ? 1 : 0,
        ]
      );

      // Add tags to tools
      const toolId = result.insertId;
      const toolTags = ['AI', 'Productivity'];
      for (const tagName of toolTags) {
        const [tagResult] = await connection.execute(
          'SELECT id FROM tags WHERE slug = ?',
          [tagName.toLowerCase().replace(/\s+/g, '-')]
        );
        if (tagResult.length > 0) {
          await connection.execute(
            'INSERT IGNORE INTO tools_tags (toolId, tagId) VALUES (?, ?)',
            [toolId, tagResult[0].id]
          );
        }
      }
    }
    console.log('✓ Sample tools seeded');

    console.log('\n✅ Database seeded successfully!');
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

seedDatabase();
