CREATE TABLE `bookmarks` (
`id` int AUTO_INCREMENT NOT NULL,
`userId` int NOT NULL,
`toolId` int NOT NULL,
`createdAt` timestamp NOT NULL DEFAULT (now()),
CONSTRAINT `bookmarks_id` PRIMARY KEY(`id`)
);

CREATE TABLE `categories` (
`id` int AUTO_INCREMENT NOT NULL,
`name` varchar(100) NOT NULL,
`slug` varchar(100) NOT NULL,
`description` text,
`createdAt` timestamp NOT NULL DEFAULT (now()),
`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
CONSTRAINT `categories_id` PRIMARY KEY(`id`),
CONSTRAINT `categories_name_unique` UNIQUE(`name`),
CONSTRAINT `categories_slug_unique` UNIQUE(`slug`)
);

CREATE TABLE `reviews` (
`id` int AUTO_INCREMENT NOT NULL,
`toolId` int NOT NULL,
`userId` int NOT NULL,
`rating` int NOT NULL,
`comment` text,
`createdAt` timestamp NOT NULL DEFAULT (now()),
`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
CONSTRAINT `reviews_id` PRIMARY KEY(`id`)
);

CREATE TABLE `tags` (
`id` int AUTO_INCREMENT NOT NULL,
`name` varchar(100) NOT NULL,
`slug` varchar(100) NOT NULL,
`createdAt` timestamp NOT NULL DEFAULT (now()),
CONSTRAINT `tags_id` PRIMARY KEY(`id`),
CONSTRAINT `tags_name_unique` UNIQUE(`name`),
CONSTRAINT `tags_slug_unique` UNIQUE(`slug`)
);

CREATE TABLE `tool_images` (
`id` int AUTO_INCREMENT NOT NULL,
`toolId` int NOT NULL,
`imageUrl` varchar(500) NOT NULL,
`alt` varchar(200),
`order` int DEFAULT 0,
`createdAt` timestamp NOT NULL DEFAULT (now()),
CONSTRAINT `tool_images_id` PRIMARY KEY(`id`)
);

CREATE TABLE `tool_submissions` (
`id` int AUTO_INCREMENT NOT NULL,
`toolId` int NOT NULL,
`submittedBy` int NOT NULL,
`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
`rejectionReason` text,
`reviewedBy` int,
`reviewedAt` timestamp,
`createdAt` timestamp NOT NULL DEFAULT (now()),
CONSTRAINT `tool_submissions_id` PRIMARY KEY(`id`)
);

CREATE TABLE `tools` (
`id` int AUTO_INCREMENT NOT NULL,
`name` varchar(200) NOT NULL,
`slug` varchar(200) NOT NULL,
`description` text NOT NULL,
`aiSummary` text,
`websiteUrl` varchar(500),
`documentationUrl` varchar(500),
`categoryId` int NOT NULL,
`pricingType` enum('free','freemium','paid','open-source') NOT NULL,
`rating` decimal(3,2) DEFAULT '0',
`reviewCount` int DEFAULT 0,
`submittedBy` int NOT NULL,
`status` enum('approved','pending','rejected') NOT NULL DEFAULT 'pending',
`rejectionReason` text,
`featured` boolean DEFAULT false,
`createdAt` timestamp NOT NULL DEFAULT (now()),
`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
CONSTRAINT `tools_id` PRIMARY KEY(`id`),
CONSTRAINT `tools_slug_unique` UNIQUE(`slug`)
);

CREATE TABLE `tools_tags` (
`toolId` int NOT NULL,
`tagId` int NOT NULL
);

CREATE INDEX `idx_userId` ON `bookmarks` (`userId`);
CREATE INDEX `idx_toolId` ON `bookmarks` (`toolId`);
CREATE INDEX `idx_toolId` ON `reviews` (`toolId`);
CREATE INDEX `idx_userId` ON `reviews` (`userId`);
CREATE INDEX `idx_toolId` ON `tool_images` (`toolId`);
CREATE INDEX `idx_toolId` ON `tool_submissions` (`toolId`);
CREATE INDEX `idx_submittedBy` ON `tool_submissions` (`submittedBy`);
CREATE INDEX `idx_status` ON `tool_submissions` (`status`);
CREATE INDEX `idx_categoryId` ON `tools` (`categoryId`);
CREATE INDEX `idx_submittedBy` ON `tools` (`submittedBy`);
CREATE INDEX `idx_status` ON `tools` (`status`);
CREATE INDEX `idx_pricingType` ON `tools` (`pricingType`);
CREATE INDEX `idx_toolId` ON `tools_tags` (`toolId`);
CREATE INDEX `idx_tagId` ON `tools_tags` (`tagId`);
