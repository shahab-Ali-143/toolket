import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, index } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Categories for organizing tools (e.g., "AI Writing", "Code Generation", "Design")
 */
export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;

/**
 * Tags for additional tool classification (e.g., "free", "open-source", "no-code")
 */
export const tags = mysqlTable("tags", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Tag = typeof tags.$inferSelect;
export type InsertTag = typeof tags.$inferInsert;

/**
 * Main tools table
 */
export const tools = mysqlTable(
  "tools",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 200 }).notNull(),
    slug: varchar("slug", { length: 200 }).notNull().unique(),
    description: text("description").notNull(),
    aiSummary: text("aiSummary"), // AI-generated summary
    websiteUrl: varchar("websiteUrl", { length: 500 }),
    documentationUrl: varchar("documentationUrl", { length: 500 }),
    categoryId: int("categoryId").notNull(),
    pricingType: mysqlEnum("pricingType", ["free", "freemium", "paid", "open-source"]).notNull(),
    rating: decimal("rating", { precision: 3, scale: 2 }).default("0"),
    reviewCount: int("reviewCount").default(0),
    submittedBy: int("submittedBy").notNull(), // User who submitted
    status: mysqlEnum("status", ["approved", "pending", "rejected"]).default("pending").notNull(),
    rejectionReason: text("rejectionReason"),
    featured: boolean("featured").default(false),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    index("idx_categoryId").on(table.categoryId),
    index("idx_submittedBy").on(table.submittedBy),
    index("idx_status").on(table.status),
    index("idx_pricingType").on(table.pricingType),
  ]
);

export type Tool = typeof tools.$inferSelect;
export type InsertTool = typeof tools.$inferInsert;

/**
 * Junction table for tools and tags (many-to-many)
 */
export const toolsTags = mysqlTable(
  "tools_tags",
  {
    toolId: int("toolId").notNull(),
    tagId: int("tagId").notNull(),
  },
  (table) => [
    index("idx_toolId").on(table.toolId),
    index("idx_tagId").on(table.tagId),
  ]
);

export type ToolTag = typeof toolsTags.$inferSelect;
export type InsertToolTag = typeof toolsTags.$inferInsert;

/**
 * Reviews and ratings for tools
 */
export const reviews = mysqlTable(
  "reviews",
  {
    id: int("id").autoincrement().primaryKey(),
    toolId: int("toolId").notNull(),
    userId: int("userId").notNull(),
    rating: int("rating").notNull(), // 1-5 stars
    comment: text("comment"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    index("idx_toolId").on(table.toolId),
    index("idx_userId").on(table.userId),
  ]
);

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;

/**
 * Bookmarks - users can save tools to their favorites
 */
export const bookmarks = mysqlTable(
  "bookmarks",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    toolId: int("toolId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("idx_userId").on(table.userId),
    index("idx_toolId").on(table.toolId),
  ]
);

export type Bookmark = typeof bookmarks.$inferSelect;
export type InsertBookmark = typeof bookmarks.$inferInsert;

/**
 * Tool submissions - tracks pending submissions for moderation
 */
export const toolSubmissions = mysqlTable(
  "tool_submissions",
  {
    id: int("id").autoincrement().primaryKey(),
    toolId: int("toolId").notNull(),
    submittedBy: int("submittedBy").notNull(),
    status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
    rejectionReason: text("rejectionReason"),
    reviewedBy: int("reviewedBy"),
    reviewedAt: timestamp("reviewedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("idx_toolId").on(table.toolId),
    index("idx_submittedBy").on(table.submittedBy),
    index("idx_status").on(table.status),
  ]
);

export type ToolSubmission = typeof toolSubmissions.$inferSelect;
export type InsertToolSubmission = typeof toolSubmissions.$inferInsert;

/**
 * Tool screenshots/images
 */
export const toolImages = mysqlTable(
  "tool_images",
  {
    id: int("id").autoincrement().primaryKey(),
    toolId: int("toolId").notNull(),
    imageUrl: varchar("imageUrl", { length: 500 }).notNull(),
    alt: varchar("alt", { length: 200 }),
    order: int("order").default(0),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("idx_toolId").on(table.toolId),
  ]
);

export type ToolImage = typeof toolImages.$inferSelect;
export type InsertToolImage = typeof toolImages.$inferInsert;

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  tools: many(tools),
  reviews: many(reviews),
  bookmarks: many(bookmarks),
  submissions: many(toolSubmissions),
}));

export const categoriesRelations = relations(categories, ({ many }) => ({
  tools: many(tools),
}));

export const tagsRelations = relations(tags, ({ many }) => ({
  tools: many(toolsTags),
}));

export const toolsRelations = relations(tools, ({ one, many }) => ({
  category: one(categories, {
    fields: [tools.categoryId],
    references: [categories.id],
  }),
  submitter: one(users, {
    fields: [tools.submittedBy],
    references: [users.id],
  }),
  tags: many(toolsTags),
  reviews: many(reviews),
  bookmarks: many(bookmarks),
  images: many(toolImages),
}));

export const toolsTagsRelations = relations(toolsTags, ({ one }) => ({
  tool: one(tools, {
    fields: [toolsTags.toolId],
    references: [tools.id],
  }),
  tag: one(tags, {
    fields: [toolsTags.tagId],
    references: [tags.id],
  }),
}));

export const reviewsRelations = relations(reviews, ({ one }) => ({
  tool: one(tools, {
    fields: [reviews.toolId],
    references: [tools.id],
  }),
  user: one(users, {
    fields: [reviews.userId],
    references: [users.id],
  }),
}));

export const bookmarksRelations = relations(bookmarks, ({ one }) => ({
  user: one(users, {
    fields: [bookmarks.userId],
    references: [users.id],
  }),
  tool: one(tools, {
    fields: [bookmarks.toolId],
    references: [tools.id],
  }),
}));

export const toolSubmissionsRelations = relations(toolSubmissions, ({ one }) => ({
  tool: one(tools, {
    fields: [toolSubmissions.toolId],
    references: [tools.id],
  }),
  submitter: one(users, {
    fields: [toolSubmissions.submittedBy],
    references: [users.id],
  }),
  reviewer: one(users, {
    fields: [toolSubmissions.reviewedBy],
    references: [users.id],
  }),
}));

export const toolImagesRelations = relations(toolImages, ({ one }) => ({
  tool: one(tools, {
    fields: [toolImages.toolId],
    references: [tools.id],
  }),
}));
