import { eq, and, like, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, tools, categories, tags, reviews, bookmarks, toolSubmissions, toolImages, toolsTags } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ TOOLS ============

export async function getApprovedTools(limit: number = 50, offset: number = 0) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(tools)
    .where(eq(tools.status, 'approved'))
    .orderBy(desc(tools.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function getFeaturedTools(limit: number = 6) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(tools)
    .where(and(eq(tools.status, 'approved'), eq(tools.featured, true)))
    .orderBy(desc(tools.rating))
    .limit(limit);
}

export async function searchTools(query: string, categoryId?: number, pricingType?: string) {
  const db = await getDb();
  if (!db) return [];

  let conditions: any[] = [eq(tools.status, 'approved')];

  if (query) {
    conditions.push(like(tools.name, `%${query}%`));
  }

  if (categoryId) {
    conditions.push(eq(tools.categoryId, categoryId));
  }

  if (pricingType) {
    conditions.push(eq(tools.pricingType, pricingType as any));
  }

  return db
    .select()
    .from(tools)
    .where(and(...conditions))
    .orderBy(desc(tools.rating));
}

export async function getToolById(toolId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(tools).where(eq(tools.id, toolId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createTool(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(tools).values(data);
  return result;
}

// ============ CATEGORIES ============

export async function getAllCategories() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(categories).orderBy(categories.name);
}

export async function getCategoryById(categoryId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(categories).where(eq(categories.id, categoryId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============ TAGS ============

export async function getAllTags() {
  const db = await getDb();
  if (!db) return [];

  return db.select().from(tags).orderBy(tags.name);
}

export async function getOrCreateTag(name: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const slug = name.toLowerCase().replace(/\s+/g, '-');

  // Try to find existing tag
  const existing = await db.select().from(tags).where(eq(tags.slug, slug)).limit(1);
  if (existing.length > 0) {
    return existing[0];
  }

  // Create new tag
  await db.insert(tags).values({ name, slug });
  // Fetch the created tag
  const created = await db.select().from(tags).where(eq(tags.slug, slug)).limit(1);
  return created[0] || { id: 0, name, slug };
}

// ============ REVIEWS ============

export async function getToolReviews(toolId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(reviews)
    .where(eq(reviews.toolId, toolId))
    .orderBy(desc(reviews.createdAt));
}

export async function createReview(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(reviews).values(data);
}

// ============ BOOKMARKS ============

export async function getUserBookmarks(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(bookmarks)
    .where(eq(bookmarks.userId, userId))
    .orderBy(desc(bookmarks.createdAt));
}

export async function addBookmark(userId: number, toolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(bookmarks).values({ userId, toolId });
}

export async function removeBookmark(userId: number, toolId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .delete(bookmarks)
    .where(and(eq(bookmarks.userId, userId), eq(bookmarks.toolId, toolId)));
}

export async function isToolBookmarked(userId: number, toolId: number) {
  const db = await getDb();
  if (!db) return false;

  const result = await db
    .select()
    .from(bookmarks)
    .where(and(eq(bookmarks.userId, userId), eq(bookmarks.toolId, toolId)))
    .limit(1);

  return result.length > 0;
}

// ============ TOOL SUBMISSIONS ============

export async function getPendingSubmissions() {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(toolSubmissions)
    .where(eq(toolSubmissions.status, 'pending'))
    .orderBy(desc(toolSubmissions.createdAt));
}

export async function createToolSubmission(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(toolSubmissions).values(data);
}

export async function approveSubmission(submissionId: number, reviewedBy: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .update(toolSubmissions)
    .set({ status: 'approved', reviewedBy, reviewedAt: new Date() })
    .where(eq(toolSubmissions.id, submissionId));
}

export async function rejectSubmission(submissionId: number, reviewedBy: number, reason: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .update(toolSubmissions)
    .set({ status: 'rejected', reviewedBy, reviewedAt: new Date(), rejectionReason: reason })
    .where(eq(toolSubmissions.id, submissionId));
}

// ============ TOOL IMAGES ============

export async function getToolImages(toolId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select()
    .from(toolImages)
    .where(eq(toolImages.toolId, toolId))
    .orderBy(toolImages.order);
}

export async function addToolImage(toolId: number, imageUrl: string, alt?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(toolImages).values({ toolId, imageUrl, alt });
}

// ============ TOOL TAGS ============

export async function getToolTags(toolId: number) {
  const db = await getDb();
  if (!db) return [];

  return db
    .select({ id: tags.id, name: tags.name, slug: tags.slug })
    .from(toolsTags)
    .innerJoin(tags, eq(toolsTags.tagId, tags.id))
    .where(eq(toolsTags.toolId, toolId));
}

export async function addToolTag(toolId: number, tagId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db.insert(toolsTags).values({ toolId, tagId });
}
