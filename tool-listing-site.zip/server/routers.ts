import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ TOOLS ============
  tools: router({
    list: publicProcedure
      .input(z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
      }))
      .query(async ({ input }) => {
        return db.getApprovedTools(input.limit, input.offset);
      }),

    featured: publicProcedure
      .input(z.object({ limit: z.number().default(6) }))
      .query(async ({ input }) => {
        return db.getFeaturedTools(input.limit);
      }),

    search: publicProcedure
      .input(z.object({
        query: z.string().optional(),
        categoryId: z.number().optional(),
        pricingType: z.enum(["free", "freemium", "paid", "open-source"]).optional(),
      }))
      .query(async ({ input }) => {
        return db.searchTools(input.query || "", input.categoryId, input.pricingType);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const tool = await db.getToolById(input.id);
        if (!tool) return null;

        const [reviews, images, tags] = await Promise.all([
          db.getToolReviews(input.id),
          db.getToolImages(input.id),
          db.getToolTags(input.id),
        ]);

        return { ...tool, reviews, images, tags };
      }),
  }),

  // ============ CATEGORIES ============
  categories: router({
    list: publicProcedure.query(async () => {
      return db.getAllCategories();
    }),
  }),

  // ============ TAGS ============
  tags: router({
    list: publicProcedure.query(async () => {
      return db.getAllTags();
    }),
  }),

  // ============ REVIEWS ============
  reviews: router({
    create: protectedProcedure
      .input(z.object({
        toolId: z.number(),
        rating: z.number().min(1).max(5),
        comment: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return db.createReview({
          toolId: input.toolId,
          userId: ctx.user.id,
          rating: input.rating,
          comment: input.comment,
        });
      }),
  }),

  // ============ BOOKMARKS ============
  bookmarks: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return db.getUserBookmarks(ctx.user.id);
    }),

    add: protectedProcedure
      .input(z.object({ toolId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        return db.addBookmark(ctx.user.id, input.toolId);
      }),

    remove: protectedProcedure
      .input(z.object({ toolId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        return db.removeBookmark(ctx.user.id, input.toolId);
      }),

    isBookmarked: protectedProcedure
      .input(z.object({ toolId: z.number() }))
      .query(async ({ input, ctx }) => {
        return db.isToolBookmarked(ctx.user.id, input.toolId);
      }),
  }),

  // ============ TOOL SUBMISSIONS ============
  submissions: router({
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(3),
        description: z.string().min(10),
        websiteUrl: z.string().url().optional(),
        documentationUrl: z.string().url().optional(),
        categoryId: z.number(),
        pricingType: z.enum(["free", "freemium", "paid", "open-source"]),
        suggestedTags: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        try {
          // Generate AI summary
          const aiSummaryResponse = await invokeLLM({
            messages: [
              {
                role: "system",
                content: "You are a concise AI tool summarizer. Generate a 1-2 sentence summary of the tool based on its name and description.",
              },
              {
                role: "user",
                content: `Tool Name: ${input.name}\n\nDescription: ${input.description}`,
              },
            ],
          });

          const aiSummary = aiSummaryResponse.choices?.[0]?.message?.content || "";

          // Create tool
          const toolResult = await db.createTool({
            name: input.name,
            slug: input.name.toLowerCase().replace(/\s+/g, '-'),
            description: input.description,
            aiSummary: aiSummary || "",
            websiteUrl: input.websiteUrl,
            documentationUrl: input.documentationUrl,
            categoryId: input.categoryId,
            pricingType: input.pricingType,
            submittedBy: ctx.user.id,
            status: "pending",
          });

          const toolId = (toolResult as any).insertId || (toolResult as any)[0]?.id || 0;

          // Create submission record
          const submissionResult = await db.createToolSubmission({
            toolId,
            submittedBy: ctx.user.id,
            status: "pending",
          });

          const submissionId = (submissionResult as any).insertId || (submissionResult as any)[0]?.id || 0;

          // Add tags
          if (input.suggestedTags && input.suggestedTags.length > 0) {
            for (const tagName of input.suggestedTags) {
              const tag = await db.getOrCreateTag(tagName);
              if (tag.id) {
                await db.addToolTag(toolId, tag.id);
              }
            }
          }

          // Notify owner
          await notifyOwner({
            title: "New Tool Submission",
            content: `${ctx.user.name || "A user"} submitted a new tool: "${input.name}". Please review it in the admin panel.`,
          });

          return {
            id: submissionId,
            toolId,
            submittedBy: ctx.user.id,
            status: "pending",
          };
        } catch (error) {
          console.error("Error creating submission:", error);
          throw error;
        }
      }),

    listPending: protectedProcedure.query(async ({ ctx }) => {
      // Only admin can view pending submissions
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized");
      }
      return db.getPendingSubmissions();
    }),

    approve: protectedProcedure
      .input(z.object({ submissionId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized");
        }
        return db.approveSubmission(input.submissionId, ctx.user.id);
      }),

    reject: protectedProcedure
      .input(z.object({ submissionId: z.number(), reason: z.string() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized");
        }
        return db.rejectSubmission(input.submissionId, ctx.user.id, input.reason);
      }),
  }),
});

export type AppRouter = typeof appRouter;
